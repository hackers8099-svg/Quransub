/// Hal erey (word) oo ka mid ah aayad.
class QuranWord {
  final int position;
  final String arabic;
  final String? translation;

  const QuranWord({
    required this.position,
    required this.arabic,
    this.translation,
  });
}

/// Aayad oo leh dhammaan erayadeeda.
class Ayah {
  final int surah;
  final int number;
  final List<QuranWord> words;

  const Ayah({
    required this.surah,
    required this.number,
    required this.words,
  });

  String get key => '$surah:$number';

  String get arabicText => words.map((w) => w.arabic).join(' ');
}
