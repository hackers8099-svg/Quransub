import 'dart:async';

import 'package:flutter/material.dart';

import 'models/ayah.dart';
import 'services/quran_api.dart';
import 'widgets/caption_view.dart';

void main() {
  runApp(const QuranCaptionApp());
}

class QuranCaptionApp extends StatelessWidget {
  const QuranCaptionApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quran Caption',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      home: const CaptionPreviewScreen(),
    );
  }
}

class CaptionPreviewScreen extends StatefulWidget {
  const CaptionPreviewScreen({super.key});

  @override
  State<CaptionPreviewScreen> createState() => _CaptionPreviewScreenState();
}

class _CaptionPreviewScreenState extends State<CaptionPreviewScreen> {
  final _api = QuranApi();

  /// Qaabab kala duwan oo caption ah.
  static const _styles = <CaptionStyle>[
    CaptionStyle(name: 'Classic'),
    CaptionStyle(
      name: 'Gold Gradient',
      highlightColor: Color(0xFFFFD54F),
      background: LinearGradient(
        colors: [Color(0xFF1B5E20), Color(0xFF004D40)],
      ),
    ),
    CaptionStyle(
      name: 'Night Blue',
      highlightColor: Color(0xFF80DEEA),
      background: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF0D1B2A), Color(0xFF1B263B)],
      ),
    ),
  ];

  Ayah? _ayah;
  String? _error;
  int _styleIndex = 0;
  int _activeWord = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final ayah = await _api.fetchAyah(surah: 75, ayah: 9, translationId: 131);
      setState(() => _ayah = ayah);
      _startHighlight();
    } catch (e) {
      setState(() => _error = e.toString());
    }
  }

  /// Tijaabo ahaan: erayga kasta 0.6 ilbiriqsi ayuu iftiimaa.
  /// Marka dambe waxaa lagu xidhi doonaa audio-ga (sync).
  void _startHighlight() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(milliseconds: 600), (_) {
      if (_ayah == null || _ayah!.words.isEmpty) return;
      setState(() {
        _activeWord = (_activeWord + 1) % _ayah!.words.length;
      });
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final style = _styles[_styleIndex];

    return Scaffold(
      appBar: AppBar(title: const Text('Quran Caption')),
      body: Center(
        child: _error != null
            ? Padding(
                padding: const EdgeInsets.all(20),
                child: Text('Qalad: $_error'),
              )
            : _ayah == null
                ? const CircularProgressIndicator()
                : CaptionView(
                    ayah: _ayah!,
                    activeWordIndex: _activeWord,
                    style: style,
                  ),
      ),
      bottomNavigationBar: BottomAppBar(
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              for (var i = 0; i < _styles.length; i++)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: ChoiceChip(
                    label: Text(_styles[i].name),
                    selected: _styleIndex == i,
                    onSelected: (_) => setState(() => _styleIndex = i),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
