import 'package:flutter/material.dart';

import '../models/ayah.dart';

/// Qaabka caption-ka (style). Midabka iyo background-ka way beddeli karaan.
class CaptionStyle {
  final String name;
  final Color textColor;
  final Color highlightColor;
  final Gradient? background;
  final double fontSize;
  final FontWeight fontWeight;

  const CaptionStyle({
    required this.name,
    this.textColor = Colors.white,
    this.highlightColor = const Color(0xFF4FC3F7),
    this.background,
    this.fontSize = 34,
    this.fontWeight = FontWeight.w600,
  });
}

/// Caption word-by-word ah. [activeWordIndex] waa erayga hadda la akhrinayo.
class CaptionView extends StatelessWidget {
  final Ayah ayah;
  final int activeWordIndex;
  final CaptionStyle style;

  const CaptionView({
    super.key,
    required this.ayah,
    required this.activeWordIndex,
    required this.style,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(gradient: style.background),
      padding: const EdgeInsets.all(20),
      child: Wrap(
        alignment: WrapAlignment.center,
        spacing: 12,
        runSpacing: 10,
        textDirection: TextDirection.rtl,
        children: List.generate(ayah.words.length, (i) {
          final word = ayah.words[i];
          final isActive = i == activeWordIndex;
          return Text(
            word.arabic,
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontFamily: 'KFGQPC', // Font-ka KFGQPC Uthmanic Hafs
              fontSize: style.fontSize,
              fontWeight: style.fontWeight,
              color: isActive ? style.highlightColor : style.textColor,
            ),
          );
        }),
      ),
    );
  }
}
