import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/ayah.dart';

/// Xogta Quran.com API v4 laga soo qaado (qoraalka + word-by-word).
///
/// Dokumentiga: https://api-docs.quran.com
class QuranApi {
  static const _base = 'https://api.quran.com/api/v4';

  /// Soo qaad hal aayad. [surah] iyo [ayah] waa lambarada (tusaale: 75, 9).
  /// [translationId] waa ID-ga tarjumaadda (tusaale: 131 = Ingiriisi Sahih).
  Future<Ayah> fetchAyah({
    required int surah,
    required int ayah,
    int? translationId,
  }) async {
    final params = <String, String>{
      'words': 'true',
      'word_fields': 'text_uthmani,translation',
      if (translationId != null) 'translations': '$translationId',
    };

    final uri = Uri.parse('$_base/verses/by_key/$surah:$ayah')
        .replace(queryParameters: params);

    final response = await http.get(uri);
    if (response.statusCode != 200) {
      throw Exception('Quran API error: ${response.statusCode}');
    }

    final data = json.decode(response.body) as Map<String, dynamic>;
    final verse = data['verse'] as Map<String, dynamic>;
    final rawWords = (verse['words'] as List<dynamic>?) ?? [];

    final words = rawWords
        .where((w) => (w as Map<String, dynamic>)['char_type_name'] == 'word')
        .map((w) {
      final m = w as Map<String, dynamic>;
      return QuranWord(
        position: m['position'] as int,
        arabic: (m['text_uthmani'] ?? m['text'] ?? '') as String,
        translation: (m['translation'] as Map<String, dynamic>?)?['text']
            as String?,
      );
    }).toList();

    return Ayah(surah: surah, number: ayah, words: words);
  }
}
