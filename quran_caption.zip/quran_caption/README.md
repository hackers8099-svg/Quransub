# Quran Caption

App-ka caption-ka Quran ah oo word-by-word ah (Flutter).

## Waxa hadda jira
- Caption word-by-word ah oo erayga hadda la akhrinayo iftiimaya
- Qaabab (styles) kala duwan: midab custom iyo gradient background
- Quran.com API v4 laga soo qaado qoraalka iyo tarjumaadda

## Qorshaha xiga
- Riwaayadaha (Hafs, Ad-Duri, iwm.) oo la doorto
- Audio sync automatic ah
- Export MP4 / MOV / PNG
- KFGQPC fonts (ku dar `assets/fonts/` oo `pubspec.yaml` ku qor)

## GitHub-ka ugu shub
1. GitHub.com ka sameey repository cusub (tusaale: `quran-caption`).
2. Faylasha oo dhan ku shub repository-ga (`main` branch).
3. Tab-ka **Actions** gali, **Build APK** dooro, kadibna **Run workflow** taabo.
4. Marka uu dhammaado, hoosta run-ka ka soo deji **quran-caption-apk** (APK-ga).

## Local-ka ku socod (ikhtiyaari)
```
flutter create --project-name quran_caption --platforms=android .
flutter pub get
flutter run
```
